import { z } from "zod";

export const GUILD_NAME = "LATAM 友";
export const GUILD_TAGLINE = "Respeito · União · Atividade · Evolução";

/** DDI + DDD + número, só dígitos. Vazio = o candidato escolhe o contato no WhatsApp. */
export const GUILD_WHATSAPP_E164 = "";

export const ESTADOS = [
  { uf: "AC", nome: "Acre" },
  { uf: "AL", nome: "Alagoas" },
  { uf: "AP", nome: "Amapá" },
  { uf: "AM", nome: "Amazonas" },
  { uf: "BA", nome: "Bahia" },
  { uf: "CE", nome: "Ceará" },
  { uf: "DF", nome: "Distrito Federal" },
  { uf: "ES", nome: "Espírito Santo" },
  { uf: "GO", nome: "Goiás" },
  { uf: "MA", nome: "Maranhão" },
  { uf: "MT", nome: "Mato Grosso" },
  { uf: "MS", nome: "Mato Grosso do Sul" },
  { uf: "MG", nome: "Minas Gerais" },
  { uf: "PA", nome: "Pará" },
  { uf: "PB", nome: "Paraíba" },
  { uf: "PR", nome: "Paraná" },
  { uf: "PE", nome: "Pernambuco" },
  { uf: "PI", nome: "Piauí" },
  { uf: "RJ", nome: "Rio de Janeiro" },
  { uf: "RN", nome: "Rio Grande do Norte" },
  { uf: "RS", nome: "Rio Grande do Sul" },
  { uf: "RO", nome: "Rondônia" },
  { uf: "RR", nome: "Roraima" },
  { uf: "SC", nome: "Santa Catarina" },
  { uf: "SP", nome: "São Paulo" },
  { uf: "SE", nome: "Sergipe" },
  { uf: "TO", nome: "Tocantins" },
] as const;

export const PATENTES = [
  "Bronze I",
  "Bronze II",
  "Bronze III",
  "Prata I",
  "Prata II",
  "Prata III",
  "Ouro I",
  "Ouro II",
  "Ouro III",
  "Ouro IV",
  "Platina I",
  "Platina II",
  "Platina III",
  "Platina IV",
  "Diamante I",
  "Diamante II",
  "Diamante III",
  "Diamante IV",
  "Heroico",
  "Grão Mestre",
] as const;

export const ESTILOS = [
  { value: "rush", label: "Rush" },
  { value: "suporte", label: "Suporte" },
  { value: "estrategico", label: "Estratégico" },
  { value: "misto", label: "Misto" },
] as const;

export const HORAS = [
  { value: "1-2h", label: "1–2 horas" },
  { value: "2-4h", label: "2–4 horas" },
  { value: "4h+", label: "4 horas ou mais" },
] as const;

export const FREQUENCIAS = [
  { value: "todos-os-dias", label: "Todos os dias" },
  { value: "quase-todos-os-dias", label: "Quase todos os dias" },
  { value: "alguns-dias", label: "Alguns dias" },
] as const;

export const SIM_NAO = [
  { value: "sim", label: "Sim" },
  { value: "nao", label: "Não" },
] as const;

export const HORARIOS = [
  { value: "manha", label: "Manhã" },
  { value: "tarde", label: "Tarde" },
  { value: "noite", label: "Noite" },
  { value: "qualquer", label: "Qualquer horário" },
] as const;

export const PILLARS = [
  { title: "Respeito", body: "Cada membro é tratado com consideração. Sem toxicidade, sem humilhação." },
  { title: "União", body: "A gente joga junto. Comunica, cobre e não abandona o time." },
  { title: "Atividade", body: "Presença nas partidas, nos treinos e nos eventos da guilda." },
  { title: "Evolução", body: "Treina, escuta a liderança e sobe de patente com o grupo." },
] as const;

const required = (message: string) =>
  z
    .string()
    .trim()
    .min(1, message);

export const recruitmentSchema = z.object({
  nome: required("Informe seu nome").min(2, "Informe seu nome"),
  idade: required("Informe sua idade").regex(/^\d{1,2}$/, "Informe uma idade válida").refine(
    (value) => {
      const age = Number(value);
      return age >= 12 && age <= 80;
    },
    "A idade deve ser entre 12 e 80 anos",
  ),
  estado: required("Selecione seu estado"),
  nick: required("Informe seu nick no Free Fire").min(2, "Informe seu nick no Free Fire"),
  idFreeFire: required("Informe seu ID")
    .regex(/^\d{8,12}$/, "O ID do Free Fire deve ter de 8 a 12 dígitos"),
  patenteAtual: required("Selecione sua patente atual"),
  patenteMaxima: required("Selecione sua patente máxima"),
  estilo: required("Selecione seu estilo de jogo"),
  horas: required("Selecione quantas horas você joga"),
  frequencia: required("Selecione sua frequência"),
  motivo: required("Conte por que quer entrar na guilda").min(
    20,
    "Escreva pelo menos 20 caracteres",
  ),
  outraGuilda: required("Responda se já participou de outra guilda"),
  atividades: required("Responda se vai participar das atividades"),
  regras: z
    .string()
    .trim()
    .min(1, "Confirme se aceita as regras")
    .refine((value) => value === "sim", "É necessário aceitar as regras da guilda"),
  whatsapp: required("Informe seu WhatsApp")
    .transform((value) => value.replace(/\D/g, ""))
    .pipe(
      z
        .string()
        .regex(/^\d{10,11}$/, "Informe um WhatsApp válido com DDD"),
    ),
  horario: required("Selecione o melhor horário"),
});

export type RecruitmentInput = z.input<typeof recruitmentSchema>;
export type RecruitmentValues = z.output<typeof recruitmentSchema>;

export const defaultValues: RecruitmentInput = {
  nome: "",
  idade: "",
  estado: "",
  nick: "",
  idFreeFire: "",
  patenteAtual: "",
  patenteMaxima: "",
  estilo: "",
  horas: "",
  frequencia: "",
  motivo: "",
  outraGuilda: "",
  atividades: "",
  regras: "",
  whatsapp: "",
  horario: "",
};

export function formatWhatsApp(value: string): string {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  if (digits.length === 0) return "";
  if (digits.length <= 2) return `(${digits}`;
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export function displayWhatsApp(digits: string): string {
  return formatWhatsApp(digits);
}

function labelOf(
  options: readonly { value: string; label: string }[],
  value: string,
): string {
  return options.find((option) => option.value === value)?.label ?? value;
}

function estadoLabel(uf: string): string {
  const match = ESTADOS.find((estado) => estado.uf === uf);
  return match ? `${match.nome} (${match.uf})` : uf;
}

export function formatApplicationMessage(values: RecruitmentValues): string {
  return [
    `*${GUILD_NAME} — Candidatura*`,
    "",
    "*Dados do jogador*",
    `Nome: ${values.nome}`,
    `Idade: ${values.idade}`,
    `Estado: ${estadoLabel(values.estado)}`,
    `Nick: ${values.nick}`,
    `ID: ${values.idFreeFire}`,
    "",
    "*Perfil*",
    `Patente atual: ${values.patenteAtual}`,
    `Patente máxima: ${values.patenteMaxima}`,
    `Estilo: ${labelOf(ESTILOS, values.estilo)}`,
    `Horas por dia: ${labelOf(HORAS, values.horas)}`,
    `Frequência: ${labelOf(FREQUENCIAS, values.frequencia)}`,
    "",
    "*Sobre a guilda*",
    `Por que quer entrar: ${values.motivo}`,
    `Já participou de outra guilda: ${labelOf(SIM_NAO, values.outraGuilda)}`,
    `Participa das atividades: ${labelOf(SIM_NAO, values.atividades)}`,
    `Aceita as regras: ${labelOf(SIM_NAO, values.regras)}`,
    "",
    "*Contato*",
    `WhatsApp: ${displayWhatsApp(values.whatsapp)}`,
    `Melhor horário: ${labelOf(HORARIOS, values.horario)}`,
  ].join("\n");
}

export function whatsappShareUrl(message: string): string {
  const encoded = encodeURIComponent(message);
  if (GUILD_WHATSAPP_E164) {
    return `https://wa.me/${GUILD_WHATSAPP_E164}?text=${encoded}`;
  }
  return `https://wa.me/?text=${encoded}`;
}

export const FIELD_LABELS: Record<keyof RecruitmentValues, string> = {
  nome: "Nome",
  idade: "Idade",
  estado: "Estado",
  nick: "Nick no Free Fire",
  idFreeFire: "ID do Free Fire",
  patenteAtual: "Patente atual",
  patenteMaxima: "Patente máxima",
  estilo: "Estilo de jogo",
  horas: "Horas por dia",
  frequencia: "Frequência",
  motivo: "Por que quer entrar",
  outraGuilda: "Já participou de outra guilda",
  atividades: "Disposto a participar das atividades",
  regras: "Aceita as regras da guilda",
  whatsapp: "WhatsApp",
  horario: "Melhor horário para contato",
};

export function displayValue(
  key: keyof RecruitmentValues,
  values: RecruitmentValues,
): string {
  switch (key) {
    case "estado":
      return estadoLabel(values.estado);
    case "estilo":
      return labelOf(ESTILOS, values.estilo);
    case "horas":
      return labelOf(HORAS, values.horas);
    case "frequencia":
      return labelOf(FREQUENCIAS, values.frequencia);
    case "outraGuilda":
    case "atividades":
    case "regras":
      return labelOf(SIM_NAO, values[key]);
    case "horario":
      return labelOf(HORARIOS, values.horario);
    case "whatsapp":
      return displayWhatsApp(values.whatsapp);
    default:
      return values[key];
  }
}
