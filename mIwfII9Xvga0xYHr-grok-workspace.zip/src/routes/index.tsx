import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Hero } from "@/components/hero";
import { Pillars } from "@/components/pillars";
import { RecruitmentForm } from "@/components/recruitment-form";
import { SiteFooter } from "@/components/site-footer";
import { SuccessView } from "@/components/success-view";
import type { RecruitmentValues } from "@/lib/recruitment";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [submitted, setSubmitted] = useState<RecruitmentValues | null>(null);

  return (
    <main className="page-bg">
      <Hero />
      {submitted ? null : <Pillars />}
      {submitted ? (
        <SuccessView values={submitted} onReset={() => setSubmitted(null)} />
      ) : (
        <RecruitmentForm onSubmitted={setSubmitted} />
      )}
      <SiteFooter />
    </main>
  );
}
