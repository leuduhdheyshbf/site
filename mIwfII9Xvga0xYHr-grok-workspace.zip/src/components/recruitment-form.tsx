import { zodResolver } from "@hookform/resolvers/zod";
import { Gamepad2, Phone, Send, Shield, User } from "lucide-react";
import { Controller, useForm } from "react-hook-form";
import { Field } from "@/components/field";
import { SectionCard } from "@/components/section-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OptionCards } from "@/components/ui/option-cards";
import { SelectField } from "@/components/ui/select-field";
import { Textarea } from "@/components/ui/textarea";
import {
  defaultValues,
  ESTADOS,
  ESTILOS,
  FREQUENCIAS,
  GUILD_NAME,
  HORARIOS,
  HORAS,
  PATENTES,
  recruitmentSchema,
  SIM_NAO,
  formatWhatsApp,
  type RecruitmentInput,
  type RecruitmentValues,
} from "@/lib/recruitment";

type RecruitmentFormProps = {
  onSubmitted: (values: RecruitmentValues) => void;
};

export function RecruitmentForm({ onSubmitted }: RecruitmentFormProps) {
  const {
    register,
    control,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<RecruitmentInput, unknown, RecruitmentValues>({
    resolver: zodResolver(recruitmentSchema),
    defaultValues,
    mode: "onSubmit",
  });

  function onInvalid() {
    requestAnimationFrame(() => {
      const first = document.querySelector("[data-error='true']");
      first?.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }

  return (
    <form
      id="formulario"
      className="mx-auto flex w-full max-w-xl flex-col gap-5 px-5 pb-20 pt-10"
      onSubmit={handleSubmit(onSubmitted, onInvalid)}
      noValidate
    >
      <SectionCard id="dados" eyebrow="01" title="Dados do jogador" icon={User}>
        <Field number={1} label="Nome" htmlFor="nome" error={errors.nome?.message}>
          <Input
            id="nome"
            autoComplete="name"
            placeholder="Seu nome"
            {...register("nome")}
          />
        </Field>

        <Field number={2} label="Idade" htmlFor="idade" error={errors.idade?.message}>
          <Input
            id="idade"
            inputMode="numeric"
            maxLength={2}
            placeholder="Ex: 18"
            {...register("idade")}
          />
        </Field>

        <Field number={3} label="Estado" htmlFor="estado" error={errors.estado?.message}>
          <SelectField id="estado" defaultValue="" {...register("estado")}>
            <option value="" disabled>
              Selecione seu estado
            </option>
            {ESTADOS.map((estado) => (
              <option key={estado.uf} value={estado.uf}>
                {estado.nome}
              </option>
            ))}
          </SelectField>
        </Field>

        <Field number={4} label="Nick no Free Fire" htmlFor="nick" error={errors.nick?.message}>
          <Input id="nick" placeholder="Seu nick" {...register("nick")} />
        </Field>

        <Field
          number={5}
          label="ID do Free Fire"
          htmlFor="idFreeFire"
          error={errors.idFreeFire?.message}
        >
          <Input
            id="idFreeFire"
            inputMode="numeric"
            maxLength={12}
            placeholder="Somente números"
            {...register("idFreeFire", {
              onChange: (event) => {
                const digits = event.target.value.replace(/\D/g, "").slice(0, 12);
                setValue("idFreeFire", digits, { shouldValidate: false });
              },
            })}
          />
        </Field>
      </SectionCard>

      <SectionCard id="perfil" eyebrow="02" title="Perfil" icon={Gamepad2}>
        <Field
          number={6}
          label="Patente atual"
          htmlFor="patenteAtual"
          error={errors.patenteAtual?.message}
        >
          <SelectField id="patenteAtual" defaultValue="" {...register("patenteAtual")}>
            <option value="" disabled>
              Selecione a patente
            </option>
            {PATENTES.map((patente) => (
              <option key={patente} value={patente}>
                {patente}
              </option>
            ))}
          </SelectField>
        </Field>

        <Field
          number={7}
          label="Patente máxima"
          htmlFor="patenteMaxima"
          error={errors.patenteMaxima?.message}
        >
          <SelectField id="patenteMaxima" defaultValue="" {...register("patenteMaxima")}>
            <option value="" disabled>
              Selecione a patente
            </option>
            {PATENTES.map((patente) => (
              <option key={`max-${patente}`} value={patente}>
                {patente}
              </option>
            ))}
          </SelectField>
        </Field>

        <Field number={8} label="Estilo de jogo" error={errors.estilo?.message}>
          <Controller
            name="estilo"
            control={control}
            render={({ field }) => (
              <OptionCards
                name={field.name}
                value={field.value}
                onChange={field.onChange}
                options={ESTILOS}
              />
            )}
          />
        </Field>

        <Field number={9} label="Quantas horas por dia você joga?" error={errors.horas?.message}>
          <Controller
            name="horas"
            control={control}
            render={({ field }) => (
              <OptionCards
                name={field.name}
                value={field.value}
                onChange={field.onChange}
                options={HORAS}
                columns="stack"
              />
            )}
          />
        </Field>

        <Field number={10} label="Você joga com frequência?" error={errors.frequencia?.message}>
          <Controller
            name="frequencia"
            control={control}
            render={({ field }) => (
              <OptionCards
                name={field.name}
                value={field.value}
                onChange={field.onChange}
                options={FREQUENCIAS}
                columns="stack"
              />
            )}
          />
        </Field>
      </SectionCard>

      <SectionCard id="guilda" eyebrow="03" title="Sobre a guilda" icon={Shield}>
        <Field
          number={11}
          label={`Por que você quer entrar na ${GUILD_NAME}?`}
          htmlFor="motivo"
          error={errors.motivo?.message}
        >
          <Textarea
            id="motivo"
            rows={4}
            maxLength={600}
            placeholder="Conte por que a guilda combina com você."
            {...register("motivo")}
          />
        </Field>

        <Field number={12} label="Já participou de outra guilda?" error={errors.outraGuilda?.message}>
          <Controller
            name="outraGuilda"
            control={control}
            render={({ field }) => (
              <OptionCards
                name={field.name}
                value={field.value}
                onChange={field.onChange}
                options={SIM_NAO}
              />
            )}
          />
        </Field>

        <Field
          number={13}
          label="Está disposto a participar das atividades da guilda?"
          error={errors.atividades?.message}
        >
          <Controller
            name="atividades"
            control={control}
            render={({ field }) => (
              <OptionCards
                name={field.name}
                value={field.value}
                onChange={field.onChange}
                options={SIM_NAO}
              />
            )}
          />
        </Field>

        <Field
          number={14}
          label="Aceita respeitar os membros e seguir as regras da guilda?"
          error={errors.regras?.message}
        >
          <Controller
            name="regras"
            control={control}
            render={({ field }) => (
              <OptionCards
                name={field.name}
                value={field.value}
                onChange={field.onChange}
                options={SIM_NAO}
              />
            )}
          />
        </Field>
      </SectionCard>

      <SectionCard id="contato" eyebrow="04" title="Contato" icon={Phone}>
        <Field
          number={15}
          label="WhatsApp para contato"
          htmlFor="whatsapp"
          error={errors.whatsapp?.message}
        >
          <Input
            id="whatsapp"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="(11) 99999-9999"
            {...register("whatsapp", {
              onChange: (event) => {
                setValue("whatsapp", formatWhatsApp(event.target.value), {
                  shouldValidate: false,
                });
              },
            })}
          />
        </Field>

        <Field number={16} label="Melhor horário para contato" error={errors.horario?.message}>
          <Controller
            name="horario"
            control={control}
            render={({ field }) => (
              <OptionCards
                name={field.name}
                value={field.value}
                onChange={field.onChange}
                options={HORARIOS}
              />
            )}
          />
        </Field>
      </SectionCard>

      <div className="submit-panel">
        <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
          <Send className="size-4" />
          Enviar candidatura
        </Button>
        <p className="mt-3 text-center text-sm leading-normal text-muted-foreground text-pretty">
          Após o envio, aguarde o contato da liderança pelo WhatsApp.
        </p>
      </div>
    </form>
  );
}
